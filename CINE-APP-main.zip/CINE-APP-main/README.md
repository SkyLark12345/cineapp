As the result of this hands on project, I could give breathe to [this UI design](https://www.xdguru.com/cinema-website-template-for-xd/) blended with `yts.mx API`

Check out [the movie torrent downloading app](https://next-js-handson-three.vercel.app/) without Ads 

# Screen captures

## Home page
<img src="https://github.com/Amila-Rukshan/NextJS-hands-on/blob/main/screenshots/Screenshot%202021-01-02%20at%2023.31.07.png" alt="home page" width="900" />

## Movie page
<img src="https://github.com/Amila-Rukshan/NextJS-hands-on/blob/main/screenshots/Screenshot%202021-01-02%20at%2023.31.28.png" alt="home page" width="900" />

## Movie search in mobile view
<img src="https://github.com/Amila-Rukshan/NextJS-hands-on/blob/main/screenshots/Screenshot%202021-01-02%20at%2023.32.39.png" alt="home page" width="300" />
